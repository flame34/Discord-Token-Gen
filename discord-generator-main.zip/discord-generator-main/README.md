# discord-generator
The generator generates unlocked Discord tokens, It uses a variety of factors to achieve this such as anti TLS fingerprinting, solving cloudflare challenges to bypass hCaptcha's anti bot detection, and more!

!!!!! CONTACT ME VIA DISCORD FOR THE SRC!!!
SamelDEV#9999 only for BTC or XMR !!!!!

🔧 How to use
👉 Run the following command:

pip install -r requirements.txt

Features:
Captcha SOLVER (using ai)
Auto Joiner
Auto Profile (makes realistic looking profile)
Verified Email
0 Flags
Online + Status (using ws connections)

🤖 Captcha solving:

The generator has a built-in hCaptcha AI solver meaning you won't have to pay for any third-parties to solve captchas for you. It has a feature to detect new captchas and has a 99.9% solving rate. It also has an undetectable motion data which contributes to the unlock rate.

✨ QoL features:

 Check if an account has the spammer or locked flag upon registering
 3 different types for token formatting when saving registered accounts
 Generates unlocked tokens w/ datacenter proxies (very cheap / free)
 Automatically set a PFP, banner, apply for hypesquad and connect to websocket
 Various methods to make 99.9% tokens unlocked
 Integrate GOLang API for realistic usernames, bios & more
 Create GUI
 
 -------------------------
 
 PREVIEW: Soon
